
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from datetime import date, datetime, time, timedelta
from pathlib import Path
from urllib.parse import urlparse, parse_qs
import json
import calendar
import threading
import subprocess
import time as clock
import base64, io, re
from PIL import Image, ImageOps, ImageEnhance
import pytesseract
import openpyxl

HOST = "127.0.0.1"
PORT = 8765

DATA_DIR = Path.home() / "overtime_manager"
DATA_FILE = DATA_DIR / "data.json"

HOLIDAYS_2026 = {
    "2026-01-03": "Duruthu Poya",
    "2026-01-15": "Thai Pongal",
    "2026-02-01": "Navam Poya",
    "2026-02-04": "Independence Day",
    "2026-02-15": "Mahasivarathri",
    "2026-03-02": "Medin Poya",
    "2026-03-21": "Ramazan",
    "2026-04-01": "Bak Poya",
    "2026-04-03": "Good Friday",
    "2026-04-13": "New Year Holiday",
    "2026-04-14": "Sinhala Tamil New Year",
    "2026-05-01": "Vesak Poya / May Day",
    "2026-05-02": "Day after Vesak",
    "2026-05-28": "Hadji Festival",
    "2026-05-30": "Adhi Poson Poya",
    "2026-06-29": "Poson Poya",
    "2026-07-29": "Esala Poya",
    "2026-08-26": "Milad-Un-Nabi",
    "2026-08-27": "Nikini Poya",
    "2026-09-26": "Binara Poya",
    "2026-10-25": "Vap Poya",
    "2026-11-08": "Deepavali",
    "2026-11-24": "Il Poya",
    "2026-12-23": "Unduvap Poya",
    "2026-12-25": "Christmas"
}


def load_data():
    DATA_DIR.mkdir(exist_ok=True)
    if DATA_FILE.exists():
        try:
            return json.loads(DATA_FILE.read_text())
        except Exception:
            pass

    return {
        "attendance": {},
        "holidays": HOLIDAYS_2026.copy()
    }


DATA = load_data()


def save_data():
    DATA_DIR.mkdir(exist_ok=True)
    DATA_FILE.write_text(json.dumps(DATA, indent=2))


def calculate(day, start, end):
    d = date.fromisoformat(day)
    s = datetime.combine(d, datetime.strptime(start, "%H:%M").time())
    e = datetime.combine(d, datetime.strptime(end, "%H:%M").time())

    if e <= s:
        e += timedelta(days=1)

    normal = 0
    periods = []
    current = s

    while current < e:
        wd = current.date()
        midnight = datetime.combine(wd + timedelta(days=1), time.min)
        eight = datetime.combine(wd, time(8, 0))
        seventeen = datetime.combine(wd, time(17, 0))

        if wd.isoformat() in DATA["holidays"]:
            kind = "holiday_ot"
            boundary = min(e, midnight)
        elif wd.weekday() == 6:
            kind = "sunday_ot"
            boundary = min(e, midnight)
        elif current < eight:
            kind = "normal_ot"
            boundary = min(e, eight)
        elif current < seventeen:
            kind = "normal"
            boundary = min(e, seventeen)
        else:
            kind = "normal_ot"
            boundary = min(e, midnight)

        minutes = int((boundary-current).total_seconds() // 60)

        if kind == "normal":
            normal += minutes
        elif periods and periods[-1][2] == kind and periods[-1][1] == current:
            periods[-1] = (periods[-1][0], boundary, kind)
        else:
            periods.append((current, boundary, kind))

        current = boundary

    actual = {"normal_ot": 0, "sunday_ot": 0, "holiday_ot": 0}
    credited = {"normal_ot": 0, "sunday_ot": 0, "holiday_ot": 0}

    for a, b, kind in periods:
        minutes = int((b-a).total_seconds() // 60)
        actual[kind] += minutes
        credited[kind] += (minutes // 30) * 0.5

    holiday_pay = credited["holiday_ot"] * 1.5
    payable = credited["normal_ot"] + credited["sunday_ot"] + holiday_pay

    return {
        "normal": round(normal / 60, 2),
        "normal_ot": round(credited["normal_ot"], 2),
        "normal_ot_actual": round(actual["normal_ot"] / 60, 2),
        "sunday_ot": round(credited["sunday_ot"], 2),
        "sunday_ot_actual": round(actual["sunday_ot"] / 60, 2),
        "holiday_ot": round(credited["holiday_ot"], 2),
        "holiday_ot_actual": round(actual["holiday_ot"] / 60, 2),
        "holiday_pay": round(holiday_pay, 2),
        "payable_ot": round(payable, 2)
    }


def get_month(year, month):
    attendance = DATA["attendance"]
    rows = []

    for day in range(1, calendar.monthrange(year, month)[1]+1):
        d = date(year, month, day)
        key = d.isoformat()

        record = attendance.get(key, {})

        rows.append({
            "date": key,
            "day": d.strftime("%a"),
            "holiday": DATA["holidays"].get(key, ""),
            "start": record.get("start", ""),
            "end": record.get("end", "")
        })

    return rows


PAGE = r"""
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Overtime Manager</title>

<style>
body {
    background:#10151d;
    color:#eee;
    font-family:Arial,sans-serif;
    padding:12px;
}
h2 {color:#65b7ff}
.panel {
    background:#1b2735;
    padding:14px;
    border-radius:12px;
    margin-bottom:14px;
}
select,input,button {
    background:#101923;
    color:white;
    border:1px solid #405268;
    border-radius:7px;
    padding:10px;
    margin:3px;
}
button {
    background:#245b88;
}
table {
    width:100%;
    border-collapse:collapse;
    min-width:620px;
}
td,th {
    padding:7px;
    border-bottom:1px solid #39485b;
    text-align:left;
    font-size:13px;
}
.wrap {overflow-x:auto}
.holiday {background:#51432b}
.sunday {background:#24394f}
.good {color:#63d6a0;font-weight:bold}
.stats {
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:7px;
}
.stat {
    background:#101923;
    padding:10px;
    border-radius:8px;
}
.stat strong {font-size:22px}
small {color:#aab8c8}
</style>
</head>

<body>

<h2>LABOUR OT MANAGER</h2>
<small>Monthly attendance and overtime calculator</small>

<div class="panel">
    <label>Month</label>
    <select id="month"></select>

    <label>Year</label>
    <select id="year"></select>

    <button onclick="loadMonth()">Load Month</button>
</div>


<div class="panel">
<h3>Scan printed attendance sheet</h3>
<small>Photograph or select a printed attendance sheet.</small><br>
<input type="file" id="sheetFile" accept="image/*,.xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" capture="environment">
<button onclick="scanSheet()">Scan sheet</button>
<p id="scanStatus"></p>
<div id="scanPreview"></div>
</div>
<div class="panel stats">
    <div class="stat"><small>Days worked</small><strong id="days">0</strong></div>
    <div class="stat"><small>Normal hours</small><strong id="normal">0</strong></div>
    <div class="stat"><small>Normal OT</small><strong id="normalot">0</strong></div>
    <div class="stat"><small>Sunday OT</small><strong id="sundayot">0</strong></div>
    <div class="stat"><small>Holiday OT hours</small><strong id="holidayot">0</strong></div>
    <div class="stat"><small>Holiday OT pay (×1.5)</small><strong id="holidaypay">0</strong></div>
    <div class="stat"><small>Total payable OT</small><strong class="good" id="payable">0</strong></div>
</div>

<div class="panel">
<div class="wrap">
<table>
<thead>
<tr>
<th>Date</th>
<th>Day / Holiday</th>
<th>Start</th>
<th>End</th>
<th>Normal</th>
<th>Normal OT</th>
<th>Sunday OT</th>
<th>Holiday OT</th>
</tr>
</thead>
<tbody id="rows"></tbody>
</table>
</div>

<br>
<button onclick="calculate()">Calculate & Save</button>
<button onclick="clearMonth()">Clear Month</button>
<p id="status"></p>
</div>

<div class="panel">
<h3>Add a holiday</h3>
<input type="date" id="holidayDate">
<input type="text" id="holidayName" placeholder="Holiday name">
<button onclick="addHoliday()">Add</button>
</div>

<div class="panel">
<h3>Calculation rules</h3>
<small>
08:00–17:00 = Normal working time.<br>
Before 08:00 and after 17:00 = OT.<br>
Sunday and listed holidays = All OT.<br>
Overnight shifts are supported.<br>
OT rounds down to completed 30-minute units.<br>
Continuous OT across midnight is rounded together.
</small>
</div>

<script>
let records=[];

const months=[
"January","February","March","April",
"May","June","July","August",
"September","October","November","December"
];

months.forEach((m,i)=>{
    month.add(new Option(m,i+1));
});

for(let y=2024;y<=2035;y++){
    year.add(new Option(y,y));
}

let now=new Date();
month.value=now.getMonth()+1;
year.value=now.getFullYear();

async function api(url,data){
    let r=await fetch(url,{
        method:data?"POST":"GET",
        headers:{"Content-Type":"application/json"},
        body:data?JSON.stringify(data):undefined
    });
    let j=await r.json();
    if(!r.ok) throw Error(j.error);
    return j;
}

async function loadMonth(){
    let result=await api(
        `/month?year=${year.value}&month=${month.value}`
    );

    records=result.rows;
    draw();
}

function draw(results={}){
    rows.innerHTML="";

    records.forEach((r,i)=>{
        let tr=document.createElement("tr");

        if(r.holiday) tr.className="holiday";
        else if(r.day==="Sun") tr.className="sunday";

        let x=results[r.date]||{};

        tr.innerHTML=`
        <td>${r.date.slice(8)}</td>
        <td>${r.holiday||r.day}</td>
        <td><input type="text" inputmode="text" placeholder="HH:MM" value="${r.start}" onchange="records[${i}].start=this.value"></td>
        <td><input type="text" inputmode="text" placeholder="HH:MM" value="${r.end}" onchange="records[${i}].end=this.value"></td>
        <td>${x.normal??"-"}</td>
        <td>${x.normal_ot??"-"}</td>
        <td>${x.sunday_ot??"-"}</td>
        <td class="good">${x.holiday_ot??"-"}</td>
        `;

        rows.appendChild(tr);
    });
}

async function calculate(){
    try{
        let result=await api("/calculate",{rows:records});

        draw(result.results);

        days.textContent=result.totals.days;
        normal.textContent=result.totals.normal.toFixed(2);
        normalot.textContent=result.totals.normal_ot.toFixed(2);
        sundayot.textContent=result.totals.sunday_ot.toFixed(2);
        holidayot.textContent=result.totals.holiday_ot.toFixed(2);
        holidaypay.textContent=result.totals.holiday_pay.toFixed(2);
        payable.textContent=result.totals.payable_ot.toFixed(2);

        status.textContent="Saved successfully.";
    }catch(e){
        status.textContent=e.message;
    }
}

async function clearMonth(){
    if(!confirm("Clear this month's attendance?"))return;

    await api("/clear",{rows:records});

    records.forEach(r=>{
        r.start="";
        r.end="";
    });

    draw();
    days.textContent="0";
    normal.textContent="0";
    normalot.textContent="0";
    sundayot.textContent="0";
    holidayot.textContent="0";
    holidaypay.textContent="0";
    payable.textContent="0";
    status.textContent="Month cleared.";
}

async function addHoliday(){
    try{
        await api("/holiday",{
            date:holidayDate.value,
            name:holidayName.value
        });

        holidayDate.value="";
        holidayName.value="";

        await loadMonth();
        status.textContent="Holiday added.";
    }catch(e){
        status.textContent=e.message;
    }
}



// SCAN_FEATURE_INSTALLED


async function scanSheet(){
    const file=document.getElementById("sheetFile").files[0];
    const msg=document.getElementById("scanStatus");

    if(!file){
        msg.textContent="Choose a photograph or Excel file first.";
        return;
    }

    if(file.size>14*1024*1024){
        msg.textContent="File must be under 14 MB.";
        return;
    }

    try{
        msg.textContent="Scanning attendance sheet...";

        const isExcel=/\.xlsx$/i.test(file.name);
        let uploaded;

        if(isExcel){
            uploaded=await new Promise((resolve,reject)=>{
                const reader=new FileReader();
                reader.onload=()=>resolve(reader.result);
                reader.onerror=reject;
                reader.readAsDataURL(file);
            });
        }else{
            uploaded=await new Promise((resolve,reject)=>{
                const img=new Image();
                const url=URL.createObjectURL(file);

                img.onload=()=>{
                    const scale=Math.min(1,2200/Math.max(img.width,img.height));
                    const canvas=document.createElement("canvas");
                    canvas.width=Math.round(img.width*scale);
                    canvas.height=Math.round(img.height*scale);
                    canvas.getContext("2d").drawImage(
                        img,0,0,canvas.width,canvas.height
                    );

                    canvas.toBlob(blob=>{
                        URL.revokeObjectURL(url);
                        if(!blob){reject(new Error("Image compression failed."));return;}
                        const reader=new FileReader();
                        reader.onload=()=>resolve(reader.result);
                        reader.onerror=reject;
                        reader.readAsDataURL(blob);
                    },"image/jpeg",0.85);
                };

                img.onerror=()=>{
                    URL.revokeObjectURL(url);
                    reject(new Error("Cannot read photograph."));
                };
                img.src=url;
            });
        }

        const result=await api("/scan",{
            image:uploaded,
            kind:isExcel?"xlsx":"image",
            year:Number(document.getElementById("year").value),
            month:Number(document.getElementById("month").value)
        });

        if(!result.entries || !result.entries.length){
            msg.textContent="No complete attendance pairs detected.";
            if(result.warnings) msg.textContent+=" "+result.warnings.join(" | ");
            return;
        }

        const updates=[];
        const outside=[];

        result.entries.forEach(entry=>{
            const record=records.find(r=>r.date===entry.date);
            if(!record){
                outside.push(entry.date);
                return;
            }
            updates.push({
                record,
                start:entry.start,
                end:entry.end
            });
        });

        if(!updates.length){
            msg.textContent="Detected dates do not match the loaded month. Check the selected month.";
            return;
        }

        const overwriting=updates.some(
            x=>x.record.start || x.record.end
        );

        if(overwriting && !confirm(
            "Some attendance entries already exist. Replace them with scanned times?"
        )){
            msg.textContent="Import cancelled. Existing entries unchanged.";
            return;
        }

        updates.forEach(x=>{
            x.record.start=x.start;
            x.record.end=x.end;
        });

        // Immediately update the existing attendance chart.
        draw();

        let message=updates.length+
            " attendance days automatically filled into the chart.";

        if(outside.length){
            message+=" Dates outside this month skipped: "+outside.join(", ");
        }

        if(result.warnings && result.warnings.length){
            message+=" Review: "+result.warnings.join(" | ");
        }

        msg.textContent=message+
            " Review the times and press Calculate & Save.";

    }catch(e){
        msg.textContent="Scanning failed: "+e.message;
    }
}

loadMonth();
</script>

</body>
</html>
"""


class Handler(BaseHTTPRequestHandler):

    def log_message(self, *args):
        pass

    def send_json(self, obj, status=200):
        raw = json.dumps(obj).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def read_data(self):
        length = int(self.headers.get("Content-Length", 0))
        if length > 20 * 1024 * 1024:
            raise ValueError("Request too large")
        return json.loads(self.rfile.read(length))

    def do_GET(self):
        path = urlparse(self.path)

        if path.path == "/":
            raw = PAGE.encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        elif path.path == "/month":
            q = parse_qs(path.query)
            y = int(q["year"][0])
            m = int(q["month"][0])

            self.send_json({"rows": get_month(y, m)})

        else:
            self.send_json({"error": "Not found"}, 404)

    def do_POST(self):
        try:
            data = self.read_data()
            path = urlparse(self.path).path



            if path == "/scan":
                import math
                from datetime import time as dt_time

                image_data = data.get("image", "")
                if not image_data.startswith("data:"):
                    raise ValueError("Invalid file upload.")

                encoded = image_data.split(",", 1)[1]
                file_bytes = base64.b64decode(encoded, validate=True)

                if len(file_bytes) > 14 * 1024 * 1024:
                    raise ValueError("File exceeds 14 MB.")

                year = int(data.get("year", date.today().year))
                month = int(data.get("month", date.today().month))
                if not 1 <= month <= 12 or not 1900 <= year <= 2100:
                    raise ValueError("Invalid selected month.")

                punches = []
                warnings = []
                raw = ""

                def parse_date_time(value):
                    if isinstance(value, datetime):
                        return value.date(), value.strftime("%H:%M")
                    if isinstance(value, date):
                        return value, None
                    if isinstance(value, dt_time):
                        return None, value.strftime("%H:%M")

                    text = str(value).strip()
                    formats = [
                        "%m/%d/%Y %I:%M %p",
                        "%m/%d/%Y %I:%M:%S %p",
                        "%m/%d/%Y %H:%M",
                        "%m-%d-%Y %I:%M %p",
                        "%d/%m/%Y %I:%M %p",
                        "%Y-%m-%d %H:%M",
                        "%m/%d/%Y %I:%M%p",
                    ]
                    for fmt in formats:
                        try:
                            v = datetime.strptime(text, fmt)
                            return v.date(), v.strftime("%H:%M")
                        except ValueError:
                            pass

                    dm = re.search(
                        r'(?<!\d)(\d{1,2})/(\d{1,2})/(\d{4})(?!\d)', text
                    )
                    tm = re.search(
                        r'(?<!\d)(\d{1,2}):(\d{2})\s*(AM|PM)(?![A-Z])',
                        text, re.I
                    )
                    if dm:
                        mm, dd, yy = map(int, dm.groups())
                        d = date(yy, mm, dd)
                        if tm:
                            hh, minute = int(tm.group(1)), int(tm.group(2))
                            if not 1 <= hh <= 12 or minute > 59:
                                raise ValueError("Invalid time: " + text)
                            if tm.group(3).upper() == "PM" and hh != 12:
                                hh += 12
                            if tm.group(3).upper() == "AM" and hh == 12:
                                hh = 0
                            return d, f"{hh:02d}:{minute:02d}"
                        return d, None

                    return None, None

                def add_punch(value, state):
                    d, t = parse_date_time(value)
                    if d and t and d.year == year and d.month == month:
                        st = state.lower().replace(" ", "")
                        if "in" in st:
                            kind = "in"
                        elif "out" in st:
                            kind = "out"
                        else:
                            return
                        punches.append((d.isoformat(), kind, t))

                if data.get("kind") == "xlsx":
                    workbook = openpyxl.load_workbook(
                        io.BytesIO(file_bytes),
                        read_only=True,
                        data_only=True
                    )
                    sheet = workbook.active
                    header_row = None
                    time_col = state_col = None

                    for row_number, row in enumerate(
                        sheet.iter_rows(min_row=1, max_row=15, values_only=True), 1
                    ):
                        headers = [
                            str(v).strip().lower() if v is not None else ""
                            for v in row
                        ]
                        for i, h in enumerate(headers):
                            if h in ("time", "date/time", "datetime", "timestamp"):
                                time_col = i
                            if h in ("state", "status", "type", "punch"):
                                state_col = i
                        if time_col is not None and state_col is not None:
                            header_row = row_number
                            break

                    if header_row is None:
                        workbook.close()
                        raise ValueError(
                            "Excel headers not found. Need columns named Time and State."
                        )

                    for row in sheet.iter_rows(
                        min_row=header_row + 1, values_only=True
                    ):
                        if len(row) <= max(time_col, state_col):
                            continue
                        value = row[time_col]
                        state = str(row[state_col] or "").strip()
                        if value is not None:
                            add_punch(value, state)

                    workbook.close()

                else:
                    image = Image.open(io.BytesIO(file_bytes))
                    image = ImageOps.exif_transpose(image).convert("L")
                    image.thumbnail((2600, 2600))
                    image = ImageOps.autocontrast(image)
                    image = ImageEnhance.Contrast(image).enhance(1.6)

                    raw = pytesseract.image_to_string(
                        image, config="--psm 6"
                    )

                    # Each printed row contains a timestamp and C/In or C/Out.
                    for line in raw.splitlines():
                        state_match = re.search(
                            r'C\s*/?\s*(IN|OUT)\b', line, re.I
                        )
                        if not state_match:
                            continue
                        add_punch(
                            line,
                            "in" if state_match.group(1).upper() == "IN" else "out"
                        )

                # Pair punches chronologically within each date.
                by_date = {}
                for d, kind, t in punches:
                    by_date.setdefault(d, []).append((kind, t))

                entries = []
                for d, day_punches in sorted(by_date.items()):
                    ins = [t for kind, t in day_punches if kind == "in"]
                    outs = [t for kind, t in day_punches if kind == "out"]

                    if not ins or not outs:
                        warnings.append(
                            d + ": unmatched punch (In=" +
                            str(len(ins)) + ", Out=" + str(len(outs)) + ")"
                        )
                        continue

                    start_time = ins[0]
                    end_time = outs[-1]

                    if end_time <= start_time:
                        warnings.append(d + ": check overnight or punch order.")
                        continue

                    entries.append({
                        "date": d,
                        "start": start_time,
                        "end": end_time
                    })

                if not punches and data.get("kind") != "xlsx":
                    warnings.append(
                        "No punch rows recognised. Check photo clarity and orientation."
                    )

                self.send_json({
                    "entries": entries,
                    "warnings": warnings,
                    "raw": raw[:5000]
                })

            elif path == "/calculate":
                results = {}
                totals = {
                    "days": 0,
                    "normal": 0,
                    "normal_ot": 0,
                    "sunday_ot": 0,
                    "holiday_ot": 0,
                    "holiday_pay": 0,
                    "payable_ot": 0
                }

                for r in data["rows"]:
                    d = r["date"]
                    start = r.get("start", "")
                    end = r.get("end", "")

                    if not start and not end:
                        DATA["attendance"].pop(d, None)
                        continue

                    if not start or not end:
                        raise ValueError(
                            f"{d}: Missing start or end time."
                        )

                    result = calculate(d, start, end)
                    results[d] = result
                    totals["days"] += 1

                    DATA["attendance"][d] = {
                        "start": start,
                        "end": end
                    }

                    for k in totals:
                        if k != "days":
                            totals[k] += result[k]

                save_data()

                self.send_json({
                    "results": results,
                    "totals": totals
                })

            elif path == "/clear":
                for r in data["rows"]:
                    DATA["attendance"].pop(r["date"], None)

                save_data()
                self.send_json({"ok": True})

            elif path == "/holiday":
                d = date.fromisoformat(data["date"])
                name = data["name"].strip()

                if not name:
                    raise ValueError("Enter a holiday name.")

                DATA["holidays"][d.isoformat()] = name
                save_data()
                self.send_json({"ok": True})

            else:
                self.send_json({"error": "Not found"}, 404)

        except Exception as e:
            self.send_json({"error": str(e)}, 400)


def main():
    DATA_DIR.mkdir(exist_ok=True)
    save_data()

    server = ThreadingHTTPServer(
        (HOST, PORT), Handler
    )

    url = f"http://{HOST}:{PORT}"

    print("\n==============================")
    print("       LABOUR OT MANAGER")
    print("==============================")
    print("Opening:", url)
    print("Keep Termux running.")
    print("Press CTRL+C to stop.\n")

    def open_browser():
        clock.sleep(1)
        try:
            subprocess.Popen(["termux-open-url", url])
        except Exception:
            pass

    threading.Thread(
        target=open_browser, daemon=True
    ).start()

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
        server.server_close()


if __name__ == "__main__":
    main()
